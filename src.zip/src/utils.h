#ifndef UTILS_H
#define UTILS_H

extern const int screenWidth;
extern const int screenHeight;

#endif // UTILS_H
