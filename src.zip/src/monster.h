#ifndef MONSTER_H
#define MONSTER_H
#include "game_constants.h"

void UpdateMonsters(Map* map, float delta);
void DrawMonsters(Map* map);

#endif
