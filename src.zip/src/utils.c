#include "utils.h"

const int screenWidth = 1200;
const int screenHeight = 800;
